package controllers;
import java.lang.*;
import models.*;

public class BusDetailController
{
	public void insertBusDetail(BusDetail b)
	{
		BusDetail busDetails[]=this.getAllBusDetail();
		
		for(int i=0;i<busDetails.length;i++)
		{
			if(busDetails[i]==null)
			{
				busDetails[i]=b;
				break;
			}
		}
		
		this.write(busDetails);
		
		
	}
	
	public void updateBusDetail(BusDetail b)
	{
		BusDetail busDetails[]=this.getAllBusDetail();
		
		for(int i=0;i<busDetails.length;i++)
		{
			if(busDetails[i]!=null)
			{
				if(busDetails[i].getBusId().equals(b.getBusId()))
				{
					busDetails[i]=b;
				}
			}
		}
		
		this.write(busDetails);
	}
	
	public void deleteBusDetail(String busId)
	{
		BusDetail busDetails[]=this.getAllBusDetail();
		
		for(int i=0;i<busDetails.length;i++)
		{
			if(busDetails[i]!=null)
			{
				if(busDetails[i].getBusId().equals(busId))
				{
					busDetails[i]=null;
				}
			}
		}
		
		this.write(busDetails);
	}
	
	public BusDetail searchBusDetail(String busId)
	{
		BusDetail busDetails[]=this.getAllBusDetail();
		
		for(int i=0;i<busDetails.length;i++)
		{
			if(busDetails[i]!=null)
			{
				if(busDetails[i].getBusId().equals(busId))
				{
					
					return busDetails[i];
				}
			}
			
		}
		
		return null;
	}
	
	public BusDetail[] getAllBusDetail()
	{
		String fileName="controllers/data/busDetails.txt";
		FileIO fio=new FileIO();
		String values[]=fio.readFile(fileName);
		
		BusDetail busDetails[]=new BusDetail[100];
		
		BusDetail b=new BusDetail();
		
		for(int i=0;i<values.length;i++)
		{
			if(values[i]!=null)
			{
				if(busDetails[i]==null)
				{
					busDetails[i]=b.formBusDetail(values[i]);
				}
			}
			
		}
		
		return busDetails;
	}
	
	public void write(BusDetail busDetails[])
	{
		String data[]=new String[100];
		
		for(int i=0;i<data.length;i++)
		{
			if(busDetails[i]!=null)
			{
				data[i]=busDetails[i].toStringBusDetail();
			}
		}
		
		String fileName="controllers/data/busDetails.txt";
		
		FileIO fio=new FileIO();
		fio.writeFile(fileName, data);
	}
}