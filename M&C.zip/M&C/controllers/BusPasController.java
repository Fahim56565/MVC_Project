package controllers;

import java.lang.*;
import models.*;

public class BusPasController
{
	public void insertBusPas(BusPas bp)
	{
		BusPas bbs[]=this.getAllBusPas();
		
		for(int i=0;i<100;i++)
		{
			if(bbs[i]==null)
			{
				bbs[i]=bp;
				break;
			}
		}
		
		this.write(bbs);
	}
	
	public void updateBusPas(BusPas bp)
	{
		BusPas bbs[]=this.getAllBusPas();
		
		for(int i=0;i<bbs.length;i++)
		{
			if(bbs[i]!=null)
			{
				if(bbs[i].getBusPasId().equals(bp.getBusPasId()))
				{
					bbs[i]=bp;
				}
			}
		}
		
		this.write(bbs);
	}
	
	public void deleteBusPas(String busPasId)
	{
		BusPas bbs[]=this.getAllBusPas();
		
		for(int i=0;i<bbs.length;i++)
		{
			if(bbs[i]!=null)
			{
				if(bbs[i].getBusPasId().equals(busPasId))
				{
					bbs[i]=null;
				}
			}
		}
		
		this.write(bbs);
	}
	
	public BusPas searchBusPas(String busPasId)
	{
		BusPas bbs[]=this.getAllBusPas();
		
		for(int i=0;i<bbs.length;i++)
		{
			if(bbs[i]!=null)
			{
				if(bbs[i].getBusPasId().equals(busPasId))
				{
					return bbs[i];
				}
			}
		}
		
		
		return null;
	}
	
	public BusPas[] searchBusPasByPassengerId(String passengerId)
	{
		BusPas bbs[]=this.getAllBusPas();
		BusPas targetBBs[]=new BusPas[100];
		
		for(int i=0;i<bbs.length;i++)
		{
			if(bbs[i]!=null)
			{
				if(bbs[i].getPassengerId().equals(passengerId))
				{
					targetBBs[i]=bbs[i];
				}
			}
		}
		
		return targetBBs;
	}
	
	public BusPas[] searchBusPasByBusPasId(String busPasId)
	{
		BusPas bbs[]=this.getAllBusPas();
		BusPas targetBBs[]=new BusPas[100];
		
		for(int i=0;i<bbs.length;i++)
		{
			if(bbs[i]!=null)
			{
				if(bbs[i].getBusPasId().equals(busPasId))
				{
					targetBBs[i]=bbs[i];
				}
			}
		}
		
		return targetBBs;
	}
	
	public BusPas[] getAllBusPas()
	{
		String fileName="controllers/data/busPass.txt";
		FileIO fio=new FileIO();
		String data[]=fio.readFile(fileName);
		BusPas bbs[]=new BusPas[100];
		BusPas bp=new BusPas();
		for(int i=0;i<data.length;i++)
		{
			if(data[i]!=null)
			{
				
				bbs[i]=bp.formBusPas(data[i]);
			}
		}
		
		return bbs;
		
	}
	
	public void write(BusPas BusPas[])
	{
		String data[]=new String[100];
		
		for(int i=0;i<data.length;i++)
		{
			if(BusPas[i]!=null)
			{
				data[i]=BusPas[i].toStringBusPas();
			}
		}
		
		FileIO fio=new FileIO();
		String fileName="controllers/data/busPass.txt";
		fio.writeFile(fileName, data);
	}

	
	
	
}