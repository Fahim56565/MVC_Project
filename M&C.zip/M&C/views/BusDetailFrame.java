package views;

import java.lang.*;
import javax.swing.*;
import java.awt.event.*;
import models.*;
import controllers.*;

public class BusDetailFrame extends JFrame implements ActionListener {
    private JButton backBtn;
    private JTable busTable;
    private JScrollPane busTableSP;
    private JPanel panel;
    private User u;

    public BusDetailFrame(User u) {
        super("All BusDetail");
        this.setSize(800, 600);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        this.panel = new JPanel();
        this.panel.setLayout(null);

        this.backBtn = new JButton("Back");
        this.backBtn.setBounds(50, 50, 100, 30);
        this.backBtn.addActionListener(this);
        this.panel.add(backBtn);

        BusDetailController bkc = new BusDetailController();
        BusDetail busList[] = bkc.getAllBusDetail();

        String busData1[][] = new String[busList.length][9];
        for (int i = 0; i < busList.length; i++) {
            if (busList[i] != null) {
                busData1[i][0] = busList[i].getBusId();
                busData1[i][1] = busList[i].getName();
                busData1[i][2] = busList[i].getCategory();
                busData1[i][3] = busList[i].getOwnerName();
                busData1[i][4] = String.valueOf(busList[i].getNoOfBus());
                busData1[i][5] = busList[i].getDetails();
            }
        }

        String head1[] = {"BusID", "Name", "Category", "OwnerName", "BUS NO.", "Details"};
        this.busTable = new JTable(busData1, head1);
        this.busTableSP = new JScrollPane(busTable);
        this.busTableSP.setBounds(50, 110, 700, 450);
        this.busTable.setEnabled(false);
        this.panel.add(busTableSP);

        this.panel.revalidate();
        this.panel.repaint();

        this.add(panel);
        this.u = u;
    }

    public void actionPerformed(ActionEvent ae) {
        String command = ae.getActionCommand();

        if (command.equals(backBtn.getText())) {
            AdminHomeFrame adf = new AdminHomeFrame(this.u);
            this.setVisible(false);
            adf.setVisible(true);
        }
    }
}

