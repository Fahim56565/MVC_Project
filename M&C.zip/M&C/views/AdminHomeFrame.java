package views;

import java.lang.*;
import javax.swing.*;
import java.awt.event.*;
import models.*;
import controllers.*;

public class AdminHomeFrame extends JFrame implements ActionListener
{
    private JPanel panel;
    private JButton adminBtn, passengerBtn, employeeBtn, busDetailsBtn, busPasBtn, transactionBtn, profileBtn, passBtn, logOutBtn;
    private User u;

    public AdminHomeFrame(User u)
    {
        super("Admin Home Frame");
        this.setSize(800,400);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        this.panel = new JPanel(); 
        this.panel.setLayout(null);

        this.adminBtn = new JButton("Admin operation");
        this.adminBtn.setBounds(50,50,150,30);
        this.adminBtn.addActionListener(this);
        this.panel.add(adminBtn);

        this.passengerBtn = new JButton("Passenger operation");
        this.passengerBtn.setBounds(210,50,150,30);
        this.passengerBtn.addActionListener(this);
        this.panel.add(passengerBtn);

        this.employeeBtn = new JButton("Employee operation");
        this.employeeBtn.setBounds(370,50,150,30);
        this.employeeBtn.addActionListener(this);
        this.panel.add(employeeBtn);

        this.busDetailsBtn = new JButton("View All BUS");
        this.busDetailsBtn.setBounds(530,50,150,30);
        this.busDetailsBtn.addActionListener(this);
        this.panel.add(busDetailsBtn);

        this.transactionBtn = new JButton("Transaction");
        this.transactionBtn.setBounds(50,100,150,30);
        this.transactionBtn.addActionListener(this);
        this.panel.add(transactionBtn);

        this.busPasBtn = new JButton("BusPass");
        this.busPasBtn.setBounds(210,100,150,30);
        this.busPasBtn.addActionListener(this);
        this.panel.add(busPasBtn);

        this.profileBtn = new JButton("Update Profile");
        this.profileBtn.setBounds(370,100,150,30);
        this.profileBtn.addActionListener(this);
        this.panel.add(profileBtn);

        this.passBtn = new JButton("Update Password");
        this.passBtn.setBounds(530,100,150,30);
        this.passBtn.addActionListener(this);
        this.panel.add(passBtn);

        this.logOutBtn = new JButton("Log Out");
        this.logOutBtn.setBounds(690,100,100,30);
        this.logOutBtn.addActionListener(this);
        this.panel.add(logOutBtn);

        this.add(panel);
        this.u = u;
    }

    public void actionPerformed(ActionEvent ae)
    {
        String command = ae.getActionCommand();

        if(adminBtn.getText().equals(command))
        {
            AdminOperationFrame aof = new AdminOperationFrame(u);
            this.setVisible(false);
            aof.setVisible(true);
        }

        if(busDetailsBtn.getText().equals(command))
        {
            this.setVisible(false);
            BusDetailFrame abf = new BusDetailFrame(this.u);
            abf.setVisible(true);
        }

        if(profileBtn.getText().equals(command))
        {
            this.setVisible(false);
            UpdateProfileFrame upf = new UpdateProfileFrame(this.u);
            upf.setVisible(true);
        }
    }
}

