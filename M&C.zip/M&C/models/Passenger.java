package models;
import java.lang.*;

public class Passenger extends User
{
    private String membershipType;

    public Passenger()
    {
        super();
    }

    public Passenger(String userId, String name, String gender, int age, String email, String phoneNo, String address, int role, String securityAns, String password, String membershipType)
    {
        super(userId, role, securityAns, password);
        this.name = name;
        this.gender = gender;
        this.age = age;
        this.email = email;
        this.phoneNo = phoneNo;
        this.address = address;
        this.membershipType = membershipType;
    }

    public void setMembershipType(String membershipType)
    {
        this.membershipType = membershipType;
    }

    public String getMembershipType()
    {
        return this.membershipType;
    }

    public String toStringPassenger()
    {
        String str = this.userId + "," + this.name + "," + this.gender + "," + this.age + "," + this.email + "," + this.phoneNo + "," + this.address + "," + this.membershipType + "\n";
        return str;
    }

    public Passenger formPassenger(String str)
    {
        String data[] = str.split(",");

        Passenger p = new Passenger();
        p.setUserId(data[0]);
        p.setName(data[1]);
        p.setGender(data[2]);
        p.setAge(Integer.parseInt(data[3]));
        p.setEmail(data[4]);
        p.setPhoneNo(data[5]);
        p.setAddress(data[6]);
        p.setMembershipType(data[7]);

        return p;
    }
}
