package models;
import java.lang.*;

public class BusPas
{
	private String busPasId;
	private String busId;
	private String passengerId;
	private String busDate;
	
	public BusPas()
	{
	}
	
	public BusPas(String busPasId, String busId, String passengerId, String busDate)
	{
		this.busPasId=busPasId;
		this.busId=busId;
		this.passengerId=passengerId;
		this.busDate=busDate;
	}
	
	
	public void setBusPasId(String busPasId)
	{
		this.busPasId=busPasId;
	}
	
	public void setBusId(String busId)
	{
		this.busId=busId;
	}
	
	public void setPassengerId(String passengerId)
	{
		this.passengerId=passengerId;
	}
	
	public void setBusDate(String busDate)
	{
		this.busDate=busDate;
	}
	
	public String getBusPasId()
	{
		return this.busPasId;
	}
	
	public String getBusId()
	{
		return this.busId;
	}
	
	public String getPassengerId()
	{
		return this.passengerId;
	}
	
	public String getBusDate()
	{
		return this.busDate;
	}
	
	public String toStringBusPas()
	{
		String str=this.busPasId+","+this.busId+","+this.passengerId+","+this.busDate+"\n";
		return str;
	}
	
	public BusPas formBusPas(String str)
	{
		String data[]=str.split(",");
		
		BusPas bp=new BusPas();
		bp.setBusPasId(data[0]);
		bp.setBusId(data[1]);
		bp.setPassengerId(data[2]);
		bp.setBusDate(data[3]);
		return bp;
		
	}
	
}