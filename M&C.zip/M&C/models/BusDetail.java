package models;
import java.lang.*;

public class BusDetail
{
    private String busId;
    private String name;
    private String category;
    private String ownerName;
    private int noOfBus;
    private String details;

    public BusDetail()
    {
    }

    public BusDetail(String busId, String name, String category, String ownerName, int noOfBus, String details)
    {
        this.busId = busId;
        this.name = name;
        this.category = category;
        this.ownerName = ownerName;
        this.noOfBus = noOfBus;
        this.details = details;
    }

    public void setBusId(String busId)
    {
        this.busId = busId;
    }

    public void setName(String name)
    {
        this.name = name;
    }

    public void setCategory(String category)
    {
        this.category = category;
    }

    public void setOwnerName(String ownerName)
    {
        this.ownerName = ownerName;
    }

    public void setNoOfBus(int noOfBus)
    {
        this.noOfBus = noOfBus;
    }

    public void setDetails(String details)
    {
        this.details = details;
    }

    public String getBusId()
    {
        return this.busId;
    }

    public String getName()
    {
        return this.name;
    }

    public String getCategory()
    {
        return this.category;
    }

    public String getOwnerName()
    {
        return this.ownerName;
    }

    public int getNoOfBus()
    {
        return this.noOfBus;
    }

    public String getDetails()
    {
        return this.details;
    }

    public String toStringBusDetail()
    {
        String str = this.busId + "," + this.name + "," + this.category + "," + this.ownerName + "," + this.noOfBus + "," + this.details + "\n";
        return str;
    }

    public BusDetail formBusDetail(String str)
    {
        String data[] = str.split(",");

        BusDetail b = new BusDetail();
        b.setBusId(data[0]);
        b.setName(data[1]);
        b.setCategory(data[2]);
        b.setOwnerName(data[3]);
        b.setNoOfBus(Integer.parseInt(data[4]));
        b.setDetails(data[5]);

        return b;
    }
}